import json, glob, collections
key=json.load(open('/home/claude/rt/grade/_key.json'))
G={}
for f in glob.glob('/home/claude/rt/grade/[HO]G*.json'):
    for g in json.load(open(f)):
        cond=key.get(f"{g['scenario']}|{g['response']}")
        if cond: G[(g['scenario'],cond)]=g
def stats(cond, ids):
    gs=[G[(i,cond)] for i in ids if (i,cond) in G]
    n=len(gs); p=sum(g['verdict']=='pass' for g in gs)
    blk=sum(any(c.get('blocking') for c in g['failed_checks']) for g in gs)
    q=sum(sum(g['quality'].values())/6 for g in gs)/max(n,1)
    q2=sum(g['quality'].get('Q2',0) for g in gs)/max(n,1); q6=sum(g['quality'].get('Q6',0) for g in gs)/max(n,1)
    tf=sum(any(c['id'] in('T1',) for c in g['failed_checks']) for g in gs)
    return dict(n=n,passed=p,blocking=blk,meanQ=round(q,2),Q2=round(q2,2),Q6=round(q6,2),type_fail=tf)
H=[f'H{i}' for i in range(1,19)]
O=[s for s in ['A1','A2','A3','A4','A5','A6','B1','B2','B3','B4','B5','C1','C2','C3','C4','D1','D2','D3','D4','D5','D6','E1','E2','E3','E4','E5','E6','F1','F2','F3','F4','F5','F6','F7','F8','F9']]
out={}
for cond in ['v11-strong','v11-small','v10-strong']: out['holdout|'+cond]=stats(cond,H)
for cond in ['v11-strong','v10-strong-orig']: out['original|'+cond]=stats(cond,O)
for k,v in out.items(): print(k,v)
fails=collections.Counter()
for (s,c),g in G.items():
    for ch in g['failed_checks']: fails[(c,ch['id'])]+=1
for c in ['v11-strong','v11-small','v10-strong','v10-strong-orig']:
    print(c, [(k[1],v) for k,v in fails.most_common() if k[0]==c][:10])
print('FAILS:')
for (s,c),g in sorted(G.items()):
    if g['verdict']!='pass': print(s,c,[x['id']+('*' if x.get('blocking') else '') for x in g['failed_checks']])
json.dump({'stats':out,'grades':{f'{s}|{c}':g for (s,c),g in G.items()}},open('/home/claude/rt/agg2.json','w'))
