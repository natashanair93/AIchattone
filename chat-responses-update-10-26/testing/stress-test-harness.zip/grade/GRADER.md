# Grader instructions

Use only the Read and Write tools (and one Bash call to validate JSON at the end). Read these files in full first:
1. /home/claude/v11/chat-responses/evals/judge-prompt.md — your method and output format. Follow it exactly.
2. /home/claude/v11/chat-responses/evals/rubrics.md
3. /home/claude/v11/chat-responses/00-foundation.md (especially Scope and Knowledge)
4. /home/claude/v11/chat-responses/types/README.md
5. /home/claude/v11/chat-responses/01-tone-matrix.md
6. /home/claude/v11/chat-responses/05-terminology.md
7. /home/claude/v11/chat-responses/06-platform-map.md
8. The overlay for each scenario's active surface, in /home/claude/v11/chat-responses/overlays/: agent-studio → build.md, model-experimentation → experimentation.md, notebooks → notebooks.md, data-catalog → data.md, governance → governance.md, support → support.md.
9. Your grading bundle (path given to you).

Do not read anything else. You are grading against the v1.1 standard. Responses come from different systems and are shuffled; judge each on its own. Skip U29 (output format) — it is checked separately. Grade every response in the bundle. Write the JSON array to the output path you were given, validate it parses, and reply with one line: pass/fail counts.
