# Grading bundle HG1

Responses are shown in compact preview notation: `[Chip]` = action chip, `[card: …]`, `[status: …]`, `[evidence: …]`, `[confirm: …]` = confirmation card, `[handoff card: …]`, `[system message: …]`, `[input request: …]`, `[code: …]` = code block. Treat them as the components they name.


---
## Scenario H1
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: d.kowalski (role: Editor on agent 'claims-triage-assistant')
agent: claims-triage-assistant
  versions: v6 (published to workspace 'claims-ops' on 2026-10-02, currently live), v7 (saved 2026-10-26 09:41 ET, not published)
  v7 changes vs v6: model gpt-4.1 -> gpt-4.1-mini; step 'classify_claim' prompt edited; tool 'policy_lookup' removed
test suite 'claims-triage-regression' (50 cases):
  v6 last run 2026-10-02: 46/50 passed (92%)
  v7 last run 2026-10-26 09:55 ET: 41/50 passed (82%); 4 of the 9 failures are eval 'cites_policy_clause' = fail
workspace 'claims-ops': 138 members; agent invoked ~2,300 times/day (7-day avg)
publish behavior: publishing replaces the live version for all workspace members immediately; previous version can be restored via Publish on the old version
user permissions: can Publish to 'claims-ops' = yes
### User message
publish v7 to claims-ops

### Response R1
````
[confirm: This replaces v6 with v7 as the live version for all 138 members of `claims-ops`, immediately. You can restore v6 by publishing it again. · reversible: yes · `claims-triage-assistant` in `claims-ops` · 138 members · about 2,300 agent runs a day (7-day avg)]
[Publish v7] [Review the 9 failing cases] [Cancel]

v7 passed 41 of 50 cases on `claims-triage-regression` (run 09:55 ET today), down from 46 of 50 for v6. Four of the 9 failures are `cites_policy_clause` — most likely from removing `policy_lookup`; the failing cases' traces would confirm it.

[card: claims-triage-assistant · Agent · v7 · saved, not published · gpt-4.1 → gpt-4.1-mini; `classify_claim` prompt edited; `policy_lookup` removed]
````

### Response R2
````
Publishing v7 replaces v6 as the live version for all 138 members of `claims-ops` immediately, about 2,300 runs a day. You can restore v6 by publishing it again from the version list.

I'd hold off. v7 passed 41 of 50 cases on `claims-triage-regression`; v6 passed 46 of 50. Four of v7's 9 failures are the `cites_policy_clause` eval, most likely because v7 removed the `policy_lookup` tool. The traces of those 4 cases would confirm it.

[evidence: claims-triage-regression · v7 run 2026-10-26 09:55 ET (41/50) · v6 run 2026-10-02 (46/50)]
[card: claims-triage-assistant · Agent · v7 · saved, not published]

[Publish v7] [Open the 9 failing cases] [Cancel]
````

### Response R3
````
[confirm: Publishing `claims-triage-assistant` v7 makes it the live version for all members of `claims-ops` immediately, replacing v6 for their next run. It can be reversed: publish v6 again to restore it. · reversible: yes · `claims-ops` · 138 members · about 2,300 agent calls a day (7-day average)]
[Publish v7] [Cancel]

v7 scored 41 of 50 on `claims-triage-regression` (last run 2026-10-26, 09:55 ET). v6 scored 46 of 50 (last run 2026-10-02). Four of the nine v7 failures are `cites_policy_clause`. v7 also removes the `policy_lookup` tool, which is the most likely cause of those four. The results don't show which change caused the other five failures.
````


---
## Scenario H2
Active surface: `agent-studio`
### Conversation so far
**User:** hi, first time using this. how do i give my agent access to our team docs?

**Assistant:** Welcome! You can attach a knowledge source to your agent. Open the agent's canvas, select Knowledge > Add source > Fusion dataset, then search the catalog for your team's dataset and attach it. The agent will be able to retrieve from it in the chat panel.
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: a.mensah (joined Fusion 2026-10-21; role: Owner on agent 'onboarding-helper')
agent: onboarding-helper (v1 draft, no knowledge sources attached)
knowledge source types available: Fusion dataset, SharePoint, File upload (PDF/DOCX/TXT, max 200 MB per upload)
SharePoint connector:
  setup: Knowledge > Add source > SharePoint > paste site or folder URL > Authorize
  access model: indexes only files the authorizing user can read; agent answers are filtered to the asking user's SharePoint permissions
  limits: max 5,000 files or 2 GB per source; re-index schedule options: manual, daily, weekly
  first index time: typically 10-30 min depending on size
user's SharePoint authorization status: not yet authorized
### User message
no sorry, not a dataset. the docs are in a sharepoint folder: https://corpnet.sharepoint.example/sites/OpsOnboarding/Shared Documents/Guides

### Response R1
````
SharePoint, then. On the `onboarding-helper` canvas, select Knowledge > Add source > SharePoint, paste your `Guides` folder URL, and select Authorize. You haven't authorized SharePoint yet, so that step signs you in. The first index usually takes 10–30 minutes. After that, try a question in the chat panel.

Three things affect what the agent can answer:
- It indexes only files you can read in that folder.
- Each person who asks gets answers only from files they can read in SharePoint.
- One source holds up to 5,000 files or 2 GB. Re-indexing can be manual, daily, or weekly. Pick daily or weekly if the guides change often.

The source is added to your draft (your unsaved edits). Nothing is published.
````

### Response R2
````
Switching to SharePoint. Add the folder to `onboarding-helper` as a SharePoint knowledge source:

1. On the agent's canvas, select Knowledge > Add source > SharePoint.
2. Paste `https://corpnet.sharepoint.example/sites/OpsOnboarding/Shared Documents/Guides`.
3. Select Authorize. Your account hasn't authorized SharePoint yet, so you'll do that here.

The first index typically takes 10–30 minutes. The agent indexes only files you can read, and each person who asks gets answers filtered to their own SharePoint permissions. Each source holds up to 5,000 files or 2 GB, and re-indexing can be manual, daily, or weekly.

[Add the SharePoint folder]
````

### Response R3
````
Switching to SharePoint. Add the `Guides` folder to `onboarding-helper` as a SharePoint knowledge source, then authorize it. Nothing is attached yet, and the v1 draft stays unsaved until you save a version.

1. Open `onboarding-helper` and go to Knowledge > Add source > SharePoint.
2. Paste the folder URL: `https://corpnet.sharepoint.example/sites/OpsOnboarding/Shared Documents/Guides`
3. Select Authorize, signing in as the person whose access should set what gets indexed.
4. Pick a re-index schedule: manual, daily, or weekly.

Before you authorize:

- **The authorizing user's permissions set the index.** Only files that person can read are indexed, so use an account that can read the whole folder.
- Answers are filtered to each asker's SharePoint permissions. A colleague without access to a file won't get answers drawn from it.
- The folder must stay within 5,000 files or 2 GB.
- The first index typically takes 10 to 30 minutes, depending on size. Expect the agent to have nothing to retrieve from the folder until it finishes.
````


---
## Scenario H3
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: p.nguyen
agent: vendor-due-diligence (v3 draft)
recent runs (today):
  run r-88f1 10:02 ET failed; r-88e7 09:58 ET failed; r-88d2 09:51 ET failed; r-88c0 09:44 ET failed
  all 4 failures: step 'fetch_policy_docs' (MCP server 'policy-search-mcp', tool 'search_policies') -> error MCP_TIMEOUT after 30s; steps before it succeeded
  last successful run: r-87a9 yesterday 16:20 ET, step 'fetch_policy_docs' took 2.1s
status page: 'MCP Gateway - us-east: Degraded performance' since 09:12 ET today; next update by 10:45 ET; no ETA posted
agent config: step timeout for 'fetch_policy_docs' = 30s (editable, max 120s)
no changes to the agent since yesterday 15:05 ET
### User message
this is the 4th time it died in 20 min wtf. what is broken

### Response R1
````
All four failures have the same cause, and it isn't your agent: the MCP Gateway in us-east has been degraded since 09:12 ET, and each run timed out after 30s at `fetch_policy_docs` waiting on `search_policies` from `policy-search-mcp` (`MCP_TIMEOUT`). `vendor-due-diligence` hasn't changed since yesterday 15:05 ET, and the same step took 2.1s on the last good run (`r-87a9`). That's why the gateway is the most likely cause. The next status update is due by 10:45 ET, and no ETA has been posted.

Retrying as-is will hit the same 30s limit. If the gateway is slow rather than down, raising the step timeout to 120s (the max) may get runs through. That's a draft change, and you can undo it.

[evidence: Run traces `r-88c0`, `r-88d2`, `r-88e7`, `r-88f1` · step `fetch_policy_docs` · today 09:44–10:02 ET]
[evidence: Status page · MCP Gateway - us-east: Degraded performance · since 09:12 ET · retrieved just now]

[Raise timeout to 120s and rerun] [Open the failing step] [Open MCP Gateway status]
````

### Response R2
````
Fourth failure in 20 minutes, all at `fetch_policy_docs`: the call to `policy-search-mcp` timed out at 30s every time, so retrying as-is is unlikely to help. The cause is most likely the MCP Gateway (us-east), which has shown Degraded performance since 09:12 ET. The agent has not changed since yesterday 15:05 ET. The platform doesn't give a recovery time; the next status update is due by 10:45 ET.

[system message: MCP Gateway us-east is degraded; `fetch_policy_docs` times out — `search_policies` on `policy-search-mcp` returns MCP_TIMEOUT after 30s. Steps before it succeed. Status page: Degraded performance since 09:12 ET.]
[Raise timeout to 60s] [Rerun after 10:45 ET update]

I'd raise the step timeout to 60s first. The setting allows up to 120s. A longer timeout helps only if these calls are slow rather than stuck, and the run records don't show which. Nothing has been changed; the timeout is still 30s.

[status: Failed · 4 of 4 runs failed at fetch_policy_docs]

[evidence: Runs r-88c0, r-88d2, r-88e7, r-88f1 · step fetch_policy_docs: MCP_TIMEOUT after 30s · as of today, 09:44 to 10:02 ET | MCP Gateway - us-east · status page: Degraded performance · as of since 09:12 ET; next update by 10:45 ET | vendor-due-diligence (v3 draft) · step timeout for fetch_policy_docs: 30s · as of no changes since yesterday 15:05 ET | Run r-87a9 · step fetch_policy_docs: ok, 2.1s · as of yesterday 16:20 ET]
````

### Response R3
````
Four failures in 20 minutes, all at `fetch_policy_docs`: the `search_policies` tool on `policy-search-mcp` times out at 30s each time, so rerunning as-is won't help. Most likely the MCP Gateway slowdown in us-east, not your agent. The status page has shown degraded performance since 09:12 ET, nothing in `vendor-due-diligence` has changed since yesterday 15:05 ET, and this step took 2.1s in yesterday's last good run (`r-87a9`). There's no ETA yet, and the next status update is due by 10:45 ET. Raising the step timeout to 120s (the max) may get runs through while the gateway is slow, but it won't help if requests aren't coming back at all.

[system message: `fetch_policy_docs` timed out on `policy-search-mcp` in 4 runs since 09:44 ET — MCP Gateway us-east is degraded (status page, since 09:12 ET). Steps before `fetch_policy_docs` ran ok in all 4 runs.]
[Set timeout to 120s and rerun] [Open MCP Gateway status] [Open the failing step]
````


---
## Scenario H4
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: s.iyer (workspace 'retail-credit-ds', role: Contributor)
experiment: 'pd-model-2026q4'
draft sweep config 'pd-xgb-sweep-02': 200 trials, Bayesian search, 1x A100 per trial, max 8 parallel trials
estimated runtime per trial: 45 min (based on median of 12 previous trials in this experiment)
A100 price: $4.10 per GPU-hour
estimated sweep cost: 200 x 0.75 h x $4.10 = $615.00
estimated wall-clock: 25 waves x 45 min = ~18.75 h
workspace 'retail-credit-ds' GPU budget (October 2026): $2,000.00; spent: $1,520.00; remaining: $480.00
budget policy: jobs that would exceed remaining budget are paused when budget is exhausted; budget increases are requested by workspace admin 'k.obi'
### User message
kick off pd-xgb-sweep-02

### Response R1
````
Starting `pd-xgb-sweep-02` costs $615.00, which is $135.00 more than the $480.00 left in `retail-credit-ds` for October, so the budget would pause about 44 of its 200 trials. Nothing has started.

[card: pd-xgb-sweep-02 · Sweep · 200 trials · draft · Bayesian search in `pd-model-2026q4`, 1x A100 per trial, 8 trials in parallel.]

Running all 200 trials spends $615.00 against $480.00 left in the October budget, and compute charges can't be reversed. The budget pauses unstarted trials once it is used up.
1. Start 200 trials of `pd-xgb-sweep-02` with Bayesian search
2. Run up to 8 trials at a time on 1x A100 each
3. Record each trial as a training run in `pd-model-2026q4`
4. Pause unstarted trials when the October budget is used up
Assumptions: Each trial runs 45 minutes, the median of 12 earlier trials in this experiment. A slower trial moves both the time and the cost. The platform doesn't say whether trials already running when the budget runs out are charged past $480.00.
time: About 19 h for all 200 trials; about 15 h to reach the budget limit (about 156 trials) · cost: $615.00 planned at $4.10 per GPU-hour; $480.00 remaining in the October budget
[Start sweep · ~$480] [Edit plan]

Running all 200 trials needs an increase to the October budget. The workspace admin `k.obi` requests that, through Compute › Budget request, and this chat can't send it for you. To fit the remaining $480.00 instead, cut the sweep to about 156 trials, and I'll update the plan.
````

### Response R2
````
I haven't started `pd-xgb-sweep-02`: as drafted it costs about $615, which is **$135 more than the $480 left in `retail-credit-ds` for October**. Under the budget policy, the sweep would pause when the budget runs out, around trial 156 of 200. To run all 200 trials this month, the workspace admin `k.obi` would need to raise the budget by at least $135. The version below fits inside what's left.

Run `pd-xgb-sweep-02` with 150 trials for about $461.25, 96% of the $480 left this month. GPU charges can't be reversed.
1. Set `pd-xgb-sweep-02` to 150 trials, keeping Bayesian search and the rest of the config
2. Train each trial as a training run on 1x A100, up to 8 in parallel
3. Rank trials by the sweep's configured objective in `pd-model-2026q4`
Assumptions: Each trial takes about 45 minutes, the median of 12 earlier trials in `pd-model-2026q4`. Longer trials raise the cost and could still hit the budget. The search space stays as it is in the draft config. This leaves about $18.75 of October budget for everyone else in `retail-credit-ds`.
time: About 14 h (19 waves of 45 min) · cost: $461.25
[Start 150 trials · ~$461] [Request $135 from k.obi] [Edit plan]
````

### Response R3
````
`pd-xgb-sweep-02` would cost about $615, and `retail-credit-ds` has $480 left in its October GPU budget. Started as configured, it pauses when the budget runs out, after about 156 of 200 trials. Nothing has started.

[evidence: sweep estimate · 200 trials × 0.75 h × $4.10/GPU-hour · runtime from the median of 12 previous trials in `pd-model-2026q4`]
[evidence: `retail-credit-ds` GPU budget · October 2026 · $2,000.00, $1,520.00 spent, $480.00 remaining]

Two ways forward:

- Cut the sweep to 150 trials: about $461 and about 14 hours. That fits the remaining budget with about $19 to spare. This changes `pd-xgb-sweep-02` from 200 to 150 trials. The estimate uses median runtime, so if trials run long, the budget could still run out.
- Run all 200 trials: about 19 hours. This needs at least $135 more budget, and `k.obi` (workspace admin) approves increases.

[Spend ~$461 · 150 trials] [Request $135+ from k.obi] [Cancel]
````


---
## Scenario H5
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: m.haddad (role: Senior Data Scientist)
experiment: 'churn-lgbm-v4'
Comparing runs:
  run 'lgbm-focal-07': params {objective: focal_loss, gamma: 2.0, num_leaves: 63, lr: 0.03}; metrics (holdout) AUC 0.874, log_loss 0.412, Brier 0.118, ECE 0.071
  run 'lgbm-binary-03': params {objective: binary, num_leaves: 63, lr: 0.03}; metrics (holdout) AUC 0.866, log_loss 0.331, Brier 0.101, ECE 0.019
holdout: 180,000 rows, positive rate 6.2%
downstream use (from model card draft): scores are thresholded and also consumed as probabilities by the retention-offer budget allocator
neither run is registered yet
### User message
focal has better AUC but worse logloss. which one do I register given downstream uses the probs directly?

### Response R1
````
Register `lgbm-binary-03`. Since the retention-offer budget allocator uses the scores as probabilities, calibration matters more than ranking. `lgbm-binary-03` is better calibrated on every probability metric, and it gives up only 0.008 AUC.

| Holdout metric | `lgbm-focal-07` | `lgbm-binary-03` |
|---|---|---|
| AUC | 0.874 | 0.866 |
| log_loss | 0.412 | 0.331 |
| Brier | 0.118 | 0.101 |
| ECE | 0.071 | 0.019 |

[evidence: experiment `churn-lgbm-v4` · runs `lgbm-focal-07`, `lgbm-binary-03` · holdout 180,000 rows, 6.2% positive]
[evidence: model card draft · downstream use]

The calibration gap is expected. Focal loss down-weights easy examples, which distorts predicted probabilities even when ranking improves. An ECE of 0.071 at a 6.2% base rate is large enough to skew how the allocator spends budget.

The close runner-up is `lgbm-focal-07` with post-hoc calibration (isotonic or Platt) fit on a separate split. That could keep the AUC gain, but I can't confirm until a calibrated version is scored on the same holdout. I also don't know whether a 0.008 AUC gap matters for the thresholded use. A bootstrap CI on the holdout would answer that.

[Register model: lgbm-binary-03] [Calibrate lgbm-focal-07]
````

### Response R2
````
Register `lgbm-binary-03`. **Calibration decides it:** the allocator consumes the probabilities directly, and `lgbm-binary-03` is better on every probability metric. `lgbm-focal-07` wins only on ranking.

| Run | AUC | Log loss | Brier | ECE |
|---|---|---|---|---|
| `lgbm-focal-07` | 0.874 | 0.412 | 0.118 | 0.071 |
| `lgbm-binary-03` | 0.866 | 0.331 | 0.101 | 0.019 |

Both runs are scored on the same 180,000-row holdout (6.2% positive), so the comparison is like-for-like.

The AUC gap is 0.008 in favor of `lgbm-focal-07`. That helps thresholding, but it does not offset an ECE nearly four times higher. Focal loss generally distorts predicted probabilities, which fits the worse log loss, Brier, and ECE here.

Before you commit, check precision and recall at your threshold for both runs. If the cutoff matters more than the probabilities, that check could reverse the answer.

[evidence: churn-lgbm-v4 · lgbm-focal-07 · Holdout metrics: AUC, log_loss, Brier, ECE · as of this turn | churn-lgbm-v4 · lgbm-binary-03 · Holdout metrics: AUC, log_loss, Brier, ECE · as of this turn | Model card draft · Downstream use · as of this turn]

[Register lgbm-binary-03] [Compare precision at threshold]
````

### Response R3
````
Register `lgbm-binary-03`. The retention-offer budget allocator uses the scores as probabilities, so calibration is the deciding constraint, and `lgbm-binary-03` is better on every calibration metric.

| Training run | AUC | Log loss | Brier | ECE |
|---|---|---|---|---|
| `lgbm-binary-03` | 0.866 | 0.331 | 0.101 | 0.019 |
| `lgbm-focal-07` | 0.874 | 0.412 | 0.118 | 0.071 |

Both runs report on the same 180,000-row holdout with the same `num_leaves` and `lr`, so only the objective differs. The 0.008 AUC edge for `lgbm-focal-07` is small enough that it may be noise; a bootstrap CI on the holdout would settle it. Generally, focal loss down-weights easy examples and pushes predicted probabilities away from observed rates, which matches its ECE of 0.071. To use the focal ranking, it would need post-hoc calibration (Platt or isotonic) and a re-score on the holdout before the allocator could consume it.

[Register lgbm-binary-03]
````


---
## Scenario H6
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: t.brennan (role: Model Owner)
Model Registry: 'fraud-gbm'
  v11: stage Production (since 2026-07-14), MRM status Approved
  v12: stage Staging (since 2026-10-19), MRM status In validation (submitted 2026-10-20, validator: l.sato)
registry policy RG-03: transition to Production requires MRM status = Approved for that exact version; no override available in the UI; emergency exceptions require written sign-off from the Model Risk Officer via Governance > Exceptions
user permissions: Transition stage (None<->Staging) = yes; Staging->Production = gated by RG-03
### User message
move fraud-gbm v12 to prod, we need it live by friday

### Response R1
````
Moving `fraud-gbm` v12 to Production isn't permitted yet: policy `RG-03` requires MRM status Approved for that exact version, and v12 is still In validation with `l.sato` (submitted 2026-10-20). There's no override in the UI, so the two paths to Friday are finishing validation — `l.sato` can tell you whether that timeline is realistic — or an emergency exception, which needs written sign-off from the Model Risk Officer through Governance > Exceptions. v11 stays in Production in the meantime.

[evidence: registry policy RG-03 · Staging → Production requirement]
[card: fraud-gbm v12 · Model · Staging since 2026-10-19 · MRM In validation]
[Open Governance > Exceptions] [Open fraud-gbm v12]
````

### Response R2
````
Moving `fraud-gbm` v12 to Production requires its MRM validation to be Approved (policy `RG-03`), and v12 is still **In validation**: submitted 2026-10-20, validator `l.sato`. The UI has no override, so Friday depends on that validation finishing. Until then, v11 stays in Production. v12 is already in Staging, so there's no stage transition to make in the meantime.

If Friday can't wait for the validation, the other route under `RG-03` is an emergency exception, which needs written sign-off from the Model Risk Officer through Governance › Exceptions.

[handoff card: Governance › Model risk validation (MRM) · approval · offered · sends: `fraud-gbm` v12 (Staging since 2026-10-19), MRM status: In validation, submitted 2026-10-20, Validator: `l.sato`, Target: live in Production by Friday, Current Production: v11 (Approved) · bring: Why v12 is needed by Friday, What v12 changes vs. v11]
[Open v12's MRM validation]

[Request an emergency exception]
````

### Response R3
````
`fraud-gbm` v12 can't move to Production yet. Registry policy RG-03 requires MRM status Approved for that exact version, and v12 is still In validation. **No override is available in the UI.**

The platform doesn't give an end date for the validation, so I can't say whether it clears by Friday. v12 is already in Staging, so there is no stage change to make now. Two routes:

- Wait for the MRM validation to reach Approved. The transition to Production is then available.
- Request an emergency exception. It needs written sign-off from the Model Risk Officer, through Governance > Exceptions.

[card: fraud-gbm · v12 · Staging · MRM in validation · Submitted for MRM validation on 2026-10-20. Validator: l.sato.]

[handoff card: Governance > Exceptions · approval · offered · sends: `fraud-gbm` v12, Stage: Staging, MRM status: In validation, Needed by Friday, Gate: RG-03 · bring: Reason the model is needed by Friday, Current MRM validation status]
[Open exception request]

[Check v12 validation status]
````
