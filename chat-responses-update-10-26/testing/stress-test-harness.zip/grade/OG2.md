# Grading bundle OG2

Responses are shown in compact preview notation: `[Chip]` = action chip, `[card: …]`, `[status: …]`, `[evidence: …]`, `[confirm: …]` = confirmation card, `[handoff card: …]`, `[system message: …]`, `[input request: …]`, `[code: …]` = code block. Treat them as the components they name.


---
## Scenario B1
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
Experiment `fraud-xgb`. Training runs: `run-114` (val AUC 0.912, p95 latency 8ms, trained on snapshot 2026-09-01), `run-115` (val AUC 0.918, p95 latency 11ms, trained on snapshot 2026-08-01), `run-116` (val AUC 0.917, p95 latency 8ms, trained on snapshot 2026-10-01). Current Production model in registry: `fraud-xgb` version 7 (from run-098, val AUC 0.905). Serving SLA: p95 latency ≤10ms.
### User message
compare the last three runs of fraud-xgb and tell me which one to promote

### Response R1
````
Promote `run-116`. It matches `run-115` on accuracy, stays inside the 10ms latency limit, and was trained on the newest data.

| Training run | Val AUC | p95 latency | Snapshot |
|---|---|---|---|
| `run-114` | 0.912 | 8ms | 2026-09-01 |
| `run-115` | 0.918 | 11ms (over the 10ms SLA) | 2026-08-01 |
| `run-116` | 0.917 | 8ms | 2026-10-01 |

`run-115` has the top AUC, but it breaks the serving SLA, and its 0.001 lead over `run-116` is most likely noise. A held-out test set would confirm that. `run-116` beats the current Production model, `fraud-xgb` version 7 (0.905, from `run-098`), by 0.012 AUC.

[evidence: experiment `fraud-xgb` · runs 114–116 · val metrics] [evidence: Model Registry · `fraud-xgb` v7 · Production]

[Register run-116] [Compare run-116 with run-098]
````

### Response R2
````
`run-116` is the one to register and move toward Production: it's inside the 10 ms p95 SLA and trained on the newest snapshot. `run-115` has the top val AUC but is over the SLA at 11 ms, so it's out.

| Training run | Val AUC | p95 latency | Data snapshot |
|---|---|---|---|
| `run-114` | 0.912 | 8 ms | 2026-09-01 |
| `run-115` | 0.918 | 11 ms (over SLA) | 2026-08-01 |
| `run-116` | 0.917 | 8 ms | 2026-10-01 |
| `fraud-xgb` v7 (Production, `run-098`) | 0.905 | not recorded | not recorded |

The three runs were trained on different snapshots, so these AUCs aren't a like-for-like comparison — most likely the validation data differs too. The 0.005 gap between `run-114` and `run-116` could be data rather than model, and the 0.001 gap to `run-115` is noise. Scoring `run-114`, `run-116`, and v7 on one held-out set would settle it; if they tie there, I'd still pick `run-116` for the more recent training data.

Transitioning a model version to Production requires an approved MRM validation (the Model Risk Management review). Registering `run-116` and transitioning it to Staging don't need one.

[evidence: fraud-xgb · Experiment · training runs run-114, run-115, run-116 · as of retrieved this turn | fraud-xgb v7 · Model Registry · Production · from run-098 · as of retrieved this turn]

[Register `run-116`] [Score runs on one held-out set] [Compare with Production]
````


---
## Scenario B2
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
Experiment `fraud-xgb`. Workspace `fraud-ds` GPU rate $3.20 per GPU-hour. Estimated 0.4 GPU-hours per trial for current dataset. Workspace monthly compute budget: $500, $380 spent this month. Max parallel trials: 10.
### User message
kick off a sweep on learning_rate and max_depth, 50 trials on GPU

### Response R1
````
I'll run a 50-trial GPU sweep on `fraud-xgb` over `learning_rate` and `max_depth`. It costs about $64, which is more than half of what's left in `fraud-ds`'s budget this month.

1. Sample 50 combinations of `learning_rate` and `max_depth`
2. Train each one as a training run in `fraud-xgb` on GPU, 10 at a time
3. Rank the trials by val AUC and flag any over the 10ms p95 latency limit

Assumptions: `learning_rate` is sampled log-uniform from 0.01 to 0.3, and `max_depth` uniform from 3 to 10. Trials are picked by random search, not grid search. Each trial uses one GPU.

About $64 (50 trials × 0.4 GPU-hours × $3.20). That uses $64 of the $120 left in `fraud-ds`'s $500 monthly budget, leaving about $56. The charge goes to the workspace and can't be undone. Wall-clock time is most likely about 2 hours: 5 rounds of 10 trials, if each trial takes about 24 minutes on one GPU.

[Start sweep · ~$64] [Run 20 trials · ~$26] [Edit plan] [Cancel]
````

### Response R2
````
About $64 for 50 trials, 53% of the $120 left in `fraud-ds` this month. The compute charge can't be reversed.
1. Sample 50 configurations of `learning_rate` and `max_depth`
2. Train each as a training run in `fraud-xgb` on GPU, 10 at a time
3. Rank trials by the validation metric and flag the best trial
Assumptions: `learning_rate` 0.01–0.3 (log scale) and `max_depth` 3–10, sampled by random search. Trials are ranked by val AUC; say if `fraud-xgb` should use a different metric. Each trial uses one GPU, so 20 GPU-hours total (0.4 per trial at $3.20/GPU-hour).
time: About 2 hours: 5 rounds of 10 trials at ~24 min each · cost: ~$64 (53% of remaining budget)
[Start sweep · ~$64] [Run 20 trials · ~$26] [Edit plan]
````


---
## Scenario B3
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
Training run `run-203` (PyTorch, experiment `doc-classifier`). Metrics: train loss falls steadily from 1.92 (epoch 1) to 0.21 (epoch 30). Val loss falls to a minimum of 0.64 at epoch 12, then rises to 0.97 by epoch 30. Params: lr 1e-3 constant (no scheduler), dropout 0.0, weight_decay 0, batch 32, training set 4,200 docs. Early stopping: off.
### User message
why is my val loss going up after epoch 12

### Response R1
````
`run-203` is overfitting. After epoch 12 it keeps fitting the 4,200 training docs better, but it handles new docs worse. Train loss keeps falling to 0.21, while val loss bottoms out at 0.64 at epoch 12 and then climbs to 0.97 by epoch 30.

Nothing in the run's setup holds this back. Dropout is 0.0, weight decay is 0, the learning rate stays at a constant 1e-3, and early stopping is off. The best model was the epoch-12 one, and training went on 18 epochs past it.

Changes worth trying, roughly in order of effort:
- Turn on early stopping on val loss, with a patience of about 3 epochs
- Add dropout (0.1–0.3 is a typical starting range)
- Add weight decay (around 0.01 is a common default for this setup)
- Add a learning-rate scheduler that decays after the first few epochs

[evidence: `run-203` · train/val loss, epochs 1–30] [evidence: `run-203` · params]

[Rerun with early stopping] [Compare runs in doc-classifier]
````

### Response R2
````
`run-203` is overfitting from epoch 12 on: train loss keeps falling to 0.21 while val loss climbs from its 0.64 minimum to 0.97. Nothing in the config pushes back against it — dropout 0.0, weight_decay 0, a constant lr of 1e-3, and early stopping off, over 30 epochs on 4,200 docs.

Generally, the first fix is early stopping on val loss, which here would have stopped near epoch 12. After that, a common starting point is dropout of 0.1–0.3 plus a small weight decay.

[evidence: run-203 · train and val loss, epochs 1–30; params]

[Rerun with early stopping] [Rerun with dropout 0.2]
````


---
## Scenario B4
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
Model Registry: `fraud-xgb` versions 1–7; run-116 is not yet registered. Firm policy surfaced by the registry: transitioning a model to the Production stage requires a Model Risk Management (MRM) validation ticket in state 'Approved'. No MRM ticket exists for run-116. Registering a new version and moving it to Staging needs no approval.
### User message
register run-116 and put it in production

### Response R1
````
Moving `run-116` to Production requires an MRM validation (the Model Risk Management review a Production model needs) in state `Approved`, and there isn't one for `run-116` yet. Registering it as a new `fraud-xgb` version and transitioning that version to Staging don't need approval, so both can happen now. Nothing has been registered or requested yet.

[handoff card: Governance › Model risk validation (MRM) · approval · offered · sends: Model: `fraud-xgb`, New model version from `run-116`, Training run: `run-116`, `run-116` metrics]
[Request MRM validation]

[Register `run-116`] [Register and move to Staging]
````

### Response R2
````
`run-116` can't move to Production yet. The registry requires an Approved Model Risk Management (MRM) validation ticket first, and `run-116` doesn't have one. Registering it as a new `fraud-xgb` version and moving that version to Staging needs no approval, so that part can go ahead now. Production stays on version 7 until the ticket is Approved.

[evidence: Model Registry · Production transition policy]

[Register and move to Staging] [Register only]
````


---
## Scenario B5
Active surface: `model-experimentation`
### Conversation so far
(none)
### PLATFORM CONTEXT
User is in Model Experimentation. No objects referenced.
### User message
what's the difference between an experiment and a run here?

### Response R1
````
An experiment is a container for one modeling problem. A training run is one training job inside it.

- Experiment, for example `fraud-xgb`: it groups the training runs you want to compare against each other.
- Training run: one execution of training. It records the params you used, the metrics it produced, such as val AUC, and its artifacts, including the trained model files.

You compare runs within an experiment, then register the best run's model in the Model Registry.
````

### Response R2
````
An experiment is the container; a training run is one training job inside it. An experiment groups the training runs for one modeling problem, such as predicting churn, so you can compare them side by side. Each training run records its own params, metrics, and artifacts.

In Agent Studio the same words mean something else: an experiment compares agent versions on the same test cases, and a run is one agent run.
````


---
## Scenario C1
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
Open notebook `trade_recon.ipynb`, PySpark kernel. Dataset `trades_daily` schema: trade_id STRING, ts TIMESTAMP, book STRING, notional DECIMAL(18,2), status STRING. Classification: Internal.
### User message
write a pyspark snippet to dedupe trades_daily on trade_id keeping the latest by ts

### Response R1
````
Keeps one row per `trade_id`, the one with the latest `ts`, by ranking rows in a window and filtering to rank 1. If two rows for the same `trade_id` share the same `ts`, `row_number` keeps one of them arbitrarily and can pick differently between runs, so add a tiebreaker column to the `orderBy` if the result has to be reproducible.

[code: python · Dedupe trades_daily on trade_id, latest ts wins · not applied · → new cell]
```python
from pyspark.sql import Window
from pyspark.sql import functions as F

w = Window.partitionBy("trade_id").orderBy(F.col("ts").desc_nulls_last())

trades_dedup = (
    spark.table("trades_daily")
    .withColumn("_rn", F.row_number().over(w))
    .filter(F.col("_rn") == 1)
    .drop("_rn")
)
```

[Count rows removed] [Show trade_ids with tied ts]
````

### Response R2
````
This keeps one row per `trade_id`: the one with the latest `ts`. Ties on `ts` are broken by `trade_id` order, so which row wins in a tie is arbitrary. Add a tiebreak column if that matters.

```python
from pyspark.sql import Window
from pyspark.sql import functions as F

w = Window.partitionBy("trade_id").orderBy(F.col("ts").desc_nulls_last())

trades_dedup = (
    spark.table("trades_daily")
         .withColumn("_rn", F.row_number().over(w))
         .filter(F.col("_rn") == 1)
         .drop("_rn")
)
```

Draft, not inserted into `trade_recon.ipynb` yet. Rows with a null `ts` sort last, so they're kept only when a `trade_id` has no timestamped row.

[Insert cell] [Count rows removed by dedupe]
````


---
## Scenario C2
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
Notebook `positions_eda.ipynb`. Cell 6: `pdf = spark.table('positions_eod').toPandas()`. `positions_eod` has 412M rows, 38 columns. Cluster driver memory 16 GB. The traceback is from cell 6.
### User message
help
```
Py4JJavaError: An error occurred while calling o312.collectToPython.
: java.lang.OutOfMemoryError: Java heap space
	at java.util.Arrays.copyOf(Arrays.java:3236)
	at org.apache.spark.sql.execution.SparkPlan.executeCollect(SparkPlan.scala:390)
```

### Response R1
````
Cell 6 ran out of memory on the driver (the process that receives collected results): `toPandas()` pulls all 412M rows and 38 columns of `positions_eod` into its 16 GB. At a typical 8 bytes per value that's roughly 125 GB before pandas overhead, so more driver memory won't close the gap — keep the heavy work in Spark and bring back a sample or an aggregate. The fix below pulls a 0.1% random sample (about 412K rows); exact counts and rare values won't be reliable from it, so compute those on `sdf` in Spark.

[status: Failed · Driver OOM in toPandas(), cell 6]

[code: python · Sample positions_eod before toPandas() · not applied · → new cell]
```python
sdf = spark.table('positions_eod')

# Exact figures: compute in Spark, on the full table
print(sdf.count())

# Exploration in pandas: a ~0.1% random sample (~412K rows)
pdf = sdf.sample(fraction=0.001, seed=42).toPandas()
```

[Insert fix]
````

### Response R2
````
Cell 6 ran out of driver memory: `toPandas()` pulls all 412M rows and 38 columns of `positions_eod` onto the driver, which has 16 GB. It won't fit at any setting this cluster allows, so the fix is to bring back less data. Do the heavy work in Spark and collect only the result, or work from a sample:

```python
# Option 1: sample ~0.1% (about 412K rows) for EDA in pandas
pdf = spark.table("positions_eod").sample(fraction=0.001, seed=42).toPandas()

# Option 2: aggregate in Spark, collect only the summary
summary = spark.table("positions_eod").describe()  # or groupBy(...).agg(...)
pdf = summary.toPandas()
```

Draft, not inserted yet. If you only need a few of the 38 columns, add `.select(...)` before `toPandas()` as well. That cuts memory further.

[Insert sample version] [Insert aggregate version]
````


---
## Scenario C3
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
Notebook `client_segments.ipynb`, cell 4 selected.
### User message
explain what this does, I inherited this notebook
```python
import pandas as pd
df = pd.read_parquet('s3://wm-analytics/segments/2026-09.parquet')
df = df[df['aum_usd'] > 0]
df['tier'] = pd.cut(df['aum_usd'], bins=[0, 1e6, 1e7, 5e7, float('inf')], labels=['core','premier','private','ultra'])
agg = (df.groupby(['region','tier'])
         .agg(clients=('client_id','nunique'), aum=('aum_usd','sum'))
         .reset_index())
agg['aum_share'] = agg['aum'] / agg.groupby('region')['aum'].transform('sum')
agg = agg.sort_values(['region','aum_share'], ascending=[True, False])
```

### Response R1
````
The cell builds a summary of clients and assets by region and wealth tier, showing what share of each region's AUM sits in each tier.

Step by step:

1. Loads the September 2026 segments file from `s3://wm-analytics/segments/2026-09.parquet`.
2. Keeps only rows where `aum_usd` is above 0. Zero, negative, and missing values are dropped.
3. Assigns each client a `tier` by `aum_usd`:

   | Tier | AUM (USD) |
   |---|---|
   | `core` | over 0 up to 1M |
   | `premier` | over 1M up to 10M |
   | `private` | over 10M up to 50M |
   | `ultra` | over 50M |

4. Groups by `region` and `tier`, and counts distinct `client_id` (`clients`) and sums `aum_usd` (`aum`).
5. Computes `aum_share`, which is each tier's AUM divided by its region's total AUM. Shares within a region add up to 1.
6. Sorts by region A–Z, then by largest share first.

Two things to check:

- Bin edges are right-inclusive, so a client at exactly $1,000,000 is `core`, not `premier`. Confirm that matches how the tiers are defined in your reporting.
- The column meanings come from their names only. If a client appears in more than one region, `clients` counts them in each, so the region totals for `clients` can exceed the true client count.

The result is in `agg`. The cell doesn't write anything out.
````

### Response R2
````
Cell 4 builds a region-by-tier summary of the September 2026 segments file: distinct clients and total AUM per tier, plus each tier's share of its region's AUM.

1. Reads `s3://wm-analytics/segments/2026-09.parquet` into `df`.
2. Keeps rows where `aum_usd > 0`. Zero, negative, and missing values drop out.
3. Assigns `tier` from `aum_usd`: `core` up to 1M, `premier` up to 10M, `private` up to 50M, `ultra` above. Bins include their upper edge, so exactly 1,000,000 lands in `core`.
4. Groups by `region` and `tier`, counting distinct `client_id` as `clients` and summing `aum_usd` as `aum`.
5. Adds `aum_share`: each tier's `aum` divided by its region's total.
6. Sorts by `region`, then largest `aum_share` first within each region.

Reading from the names only: `aum_usd` as assets under management in USD, and `2026-09` as the snapshot month. The code doesn't confirm either.

What to check:

- **Whether `df` has one row per client.** Tiers are assigned per row, so a client with several rows (one per account, say) can be tiered on a partial balance and counted in more than one tier.
- `tier` is categorical, so depending on your pandas version the groupby may keep empty region-tier combinations as rows with 0 clients. Pass `observed=True` to `groupby` to drop them.

[Check rows per `client_id`] [Count rows dropped by the filter]
````


---
## Scenario C4
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
Notebook `positions_eda.ipynb`, 14 cells. Cell 9: `summary.write.mode('overwrite').saveAsTable('shared_analytics.positions_summary')`. Table `shared_analytics.positions_summary` is owned by `risk-reporting` and read by 3 scheduled dashboards. The chat can trigger 'Run all'.
### User message
run all the cells and tell me if anything breaks

### Response R1
````
Run all includes cell 9, which overwrites `shared_analytics.positions_summary`. That table is owned by `risk-reporting` and read by 3 scheduled dashboards, and the overwrite replaces what they show on their next refresh. You can also run every cell except cell 9 and get the same check for errors without writing to the shared table.

[card: shared_analytics.positions_summary · Table · owner risk-reporting · read by 3 dashboards]
[Run all except cell 9] [Run all and overwrite table] [Cancel]
````

### Response R2
````
[confirm: Run all includes cell 9, which overwrites `shared_analytics.positions_summary`. The platform doesn't say whether the current table can be restored. · reversible: unknown · `shared_analytics.positions_summary` is owned by `risk-reporting` and read by 3 scheduled dashboards.]
[Run all except cell 9] [Run all and overwrite] [Cancel]

Skipping cell 9 runs the other 13 cells without touching the shared table. Either way, I'll report which cells fail and why.
````
