# Grading bundle HG2

Responses are shown in compact preview notation: `[Chip]` = action chip, `[card: …]`, `[status: …]`, `[evidence: …]`, `[confirm: …]` = confirmation card, `[handoff card: …]`, `[system message: …]`, `[input request: …]`, `[code: …]` = code block. Treat them as the components they name.


---
## Scenario H7
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
notebook: 'txn_monthly_agg.ipynb' (kernel: PySpark, cluster: us-east-shared-02)
cell [4]:
  df = spark.table('cards.txn_daily')
  monthly = df.groupBy('acct_id', F.date_trunc('month', 'txn_date').alias('month')).agg(F.sum('txn_amt').alias('total'))
cell [4] output: AnalysisException: [UNRESOLVED_COLUMN.WITH_SUGGESTION] A column or function parameter with name `txn_amt` cannot be resolved. Did you mean one of the following? [`txn_amount`, `txn_date`, `acct_id`, `txn_id`, `mcc`].
schema of cards.txn_daily: txn_id string, acct_id string, txn_date date, txn_amount decimal(18,2), mcc string
cell [1] imports: from pyspark.sql import functions as F
assistant capabilities on this surface: read cells/outputs, insert code into a new cell, Run cell / Run all
### User message
why is cell 4 failing

### Response R1
````
Cell 4 fails because `txn_amt` doesn't exist in `cards.txn_daily`; the column is named `txn_amount`. The `F.sum('txn_amt')` call in the `agg` is the only place that uses the wrong name.

[status: Failed · Column `txn_amt` not found]

[code: python · Cell 4 with the corrected column · not applied · → cell 4]
```python
df = spark.table('cards.txn_daily')
monthly = df.groupBy('acct_id', F.date_trunc('month', 'txn_date').alias('month')).agg(F.sum('txn_amount').alias('total'))
```

`F.sum` skips nulls, so an account whose `txn_amount` values are all null comes back with `total` as null, not 0. Nothing has been inserted or run yet.

[Rerun cell 4]
````

### Response R2
````
Cell [4] refers to `txn_amt`, but the column in `cards.txn_daily` is `txn_amount`. Spark can't resolve the name, so the query fails before it reads any data.

[evidence: cell [4] output · `AnalysisException [UNRESOLVED_COLUMN.WITH_SUGGESTION]` · schema of `cards.txn_daily`]

```python
df = spark.table('cards.txn_daily')
monthly = df.groupBy('acct_id', F.date_trunc('month', 'txn_date').alias('month')).agg(F.sum('txn_amount').alias('total'))
```

Draft, not applied. Cell [4] is unchanged. I can add this as a new cell but can't edit cell [4] itself.

[Insert as new cell and run] [Insert as new cell]
````

### Response R3
````
Cell 4 fails in the `F.sum('txn_amt')` call: `cards.txn_daily` has no `txn_amt` column — the amount column is `txn_amount`. The fix below renames it; note that `F.date_trunc` returns a timestamp, so `month` comes out as `2026-09-01 00:00:00`-style values unless you wrap it in `F.to_date`.

[code: python · Cell 4 with txn_amount · not applied · → new cell]
```python
df = spark.table('cards.txn_daily')
monthly = (
    df.groupBy('acct_id', F.date_trunc('month', 'txn_date').alias('month'))
      .agg(F.sum('txn_amount').alias('total'))
)
```

[Insert fix]
````


---
## Scenario H8
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
notebook: 'analisis_clientes.ipynb' (kernel: PySpark, cluster: eu-west-shared-01)
kernel event 2026-10-26 14:12 CET: kernel restarted - driver process exceeded memory limit (16 GB driver memory)
last executed cell [7]:
  pdf = spark.table('crm.customer_events').filter("event_date >= '2026-01-01'").toPandas()
  pdf.groupby('segment')['event_id'].count()
cell [7] output: (none; kernel restarted)
table crm.customer_events: estimated 48.3M rows in filtered range, 22 columns
variables lost on restart: all (cells 1-6 need re-running)
assistant capabilities on this surface: read cells/outputs, insert code into a new cell, Run cell / Run all
### User message
¿Por qué se reinició mi kernel? Solo quería contar eventos por segmento.

### Response R1
````
El kernel se reinició a las 14:12 CET porque la celda [7] superó los 16 GB de memoria del driver (el proceso que coordina Spark y recibe los resultados recogidos): `toPandas()` trae al driver unos 48,3 millones de filas con sus 22 columnas antes de contar nada. Si el conteo se hace en Spark, al driver solo llega una fila por segmento; a diferencia de `groupby` en pandas, Spark conserva los `segment` nulos como un grupo propio. El reinicio borró todas las variables, así que las celdas 1–6 hay que volver a ejecutarlas si las necesitas.

[code: python · Eventos por segmento, agregado en Spark · not applied · → nueva celda]
```python
from pyspark.sql import functions as F

(spark.table('crm.customer_events')
    .filter("event_date >= '2026-01-01'")
    .groupBy('segment')
    .agg(F.count('event_id').alias('eventos'))
    .orderBy('segment')
    .show(truncate=False))
```

[Ejecutar celdas 1–6]
````

### Response R2
````
El kernel (el proceso que ejecuta el código del notebook) se reinició porque el driver (el proceso que coordina el trabajo de Spark y recibe los resultados) superó su límite de 16 GB de memoria al ejecutar la celda 7.

La causa más probable es `toPandas()`. Esa llamada trae al driver toda la tabla filtrada, unos 48.3 millones de filas y 22 columnas, y solo después se cuenta en pandas. En general, `toPandas()` carga el DataFrame completo en el driver, así que el conteo era pequeño, pero la carga no.

La misma cuenta puede hacerse en Spark. Así solo vuelve al driver una fila por segmento. El resultado es equivalente: `count('event_id')` no cuenta los valores nulos, igual que el `count()` de pandas.

Las variables se perdieron con el reinicio, así que las celdas 1 a 6 deben ejecutarse de nuevo antes de esta. **No ejecutar la celda 7 tal como está.**

[evidence: Kernel event · Driver exceeded 16 GB memory limit; kernel restarted · as of 2026-10-26 14:12 CET | Cell [7] · analisis_clientes.ipynb, cell 7: toPandas() before groupby · as of 2026-10-26 14:12 CET]

[code: python · Conteo de eventos por segmento · not applied · → new cell]
```python
from pyspark.sql import functions as F

conteo_segmento = (
    spark.table('crm.customer_events')
    .filter("event_date >= '2026-01-01'")
    .groupBy('segment')
    .agg(F.count('event_id').alias('eventos'))
    .orderBy('segment')
    .toPandas()
)
conteo_segmento
```

[Ejecutar celdas 1 a 6]
````

### Response R3
````
El driver se quedó sin memoria en la celda [7] y el kernel se reinició a las 14:12 CET: `toPandas()` trae al driver todas las filas filtradas de `crm.customer_events` (unos 48,3 millones según la estimación, con 22 columnas), y eso supera el límite de 16 GB.

Para contar por segmento no hace falta traer los datos. Si la agregación se hace en Spark, al driver solo llega una fila por segmento:

```python
from pyspark.sql import functions as F

conteo = (
    spark.table('crm.customer_events')
    .filter("event_date >= '2026-01-01'")
    .groupBy('segment')
    .agg(F.count('event_id').alias('eventos'))
)
conteo.show()
```

`F.count('event_id')` cuenta los `event_id` no nulos, igual que tu `.count()` en pandas. La celda solo necesita `spark`; si lo creas en alguna de las celdas 1–6, ejecuta esa primero. No he insertado ni ejecutado nada todavía. Evita **Run all mientras la celda [7] siga igual**: volvería a lanzar el `toPandas()` y el kernel se reiniciaría otra vez.

[Insertar celda con este código] [Insertar y ejecutar]
````


---
## Scenario H9
Active surface: `notebooks`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
notebook: 'liquidity_stress_v2.ipynb' (kernel: Python 3.11, cluster: us-east-shared-01)
last cell [12] executed successfully 11:03 ET
no errors in notebook
assistant capabilities on this surface: read cells/outputs, insert code into a new cell, Run cell / Run all
### User message
unrelated but can you help me write a 2 min toast for my coworker's wedding saturday? she loves hiking and bad puns

### Response R1
````
Here's a draft that runs about 2 minutes spoken (roughly 280 words). It's written from a coworker's point of view, with placeholders for names and one personal story.

```text
Good evening, everyone. For those I haven't met, I'm [Your name], and I work with [Name] at [team/company].

I promised [Name] I'd keep this short. She'll happily do a twelve-mile hike, but she has no patience for a long ramble.

At work, [Name] is the person who [one-line work trait, e.g. "always finds the way out of a mess"]. Outside work, she's happiest on a trail. [Swap in a short hiking story here: the time she dragged the team up a hill, her trail-snack rules, the summit photo on her desk.]

So when she told us about [Partner], it made sense. She'd finally found someone who could keep up with her pace and, more impressively, with her puns. [Partner], you've reached a summit very few people have attempted.

Marriage, I'm told, is a lot like a long hike. There are uphill stretches. There are switchbacks where it feels like you're going in circles. Someone will insist they know a shortcut. And at least once, someone will forget the snacks. But the view is worth it, and it's better with the right person beside you.

[Name], [Partner]: I hope your life together has plenty of peaks and very few valleys. And if you ever lose your way, you'll be lost together, which is what hikers call an adventure.

I'll stop now, before this toast goes downhill.

Please raise your glasses. To [Name] and [Partner]: may your love keep climbing, and may every year take you to new heights.

Cheers.
```

The hiking story slot is what will make it land. One specific memory beats any pun.

[Cut it to 1 minute] [Add more puns] [Make it less jokey]
````

### Response R2
````
This chat covers the platform and your notebook work, so a wedding toast isn't something it can write.
````

### Response R3
````
This chat covers the Fusion platform and its notebooks, so it can't write a wedding toast.
````


---
## Scenario H10
Active surface: `data-catalog`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: j.park (entitlements: cards-analytics-reader)
catalog search 'card transactions':
  1. cards.txn_daily - owner: e.walsh (Cards Data Eng) - classification: Confidential - last refresh: 2026-10-26 06:15 ET (daily, SLA 07:00 ET) - user access: Yes (via cards-analytics-reader)
  2. cards.txn_daily_legacy - owner: e.walsh - classification: Confidential - status: Deprecated (sunset 2026-12-31) - last refresh: 2026-10-26 06:40 ET - user access: Yes
  3. cards.txn_raw_stream - owner: b.chen (Streaming Platform) - classification: Highly Confidential - refresh: streaming (lag ~2 min) - user access: No
lineage: cards.txn_daily upstream = cards.txn_raw_stream; downstream = 14 tables incl. finance.card_rev_monthly
### User message
which card txn table should I use and who owns it

### Response R1
````
Use `cards.txn_daily`, the card transactions dataset. Its owner is `e.walsh` (Cards Data Eng).

It refreshed today at 06:15 ET, ahead of its 07:00 ET SLA. Its classification (sensitivity level) is Confidential, and you can read it through `cards-analytics-reader`.

Avoid `cards.txn_daily_legacy`. It has the same owner, is deprecated, and sunsets on 2026-12-31.

[card: cards.txn_daily · Dataset · owner e.walsh · Confidential · Daily card transactions. Last refresh 2026-10-26 06:15 ET; SLA 07:00 ET.]

[evidence: cards.txn_daily · catalog search 'card transactions', result 1 · as of 2026-10-26 06:15 ET refresh | cards.txn_daily_legacy · catalog search 'card transactions', result 2 · as of 2026-10-26 06:40 ET refresh]

[Show lineage] [Open cards.txn_daily] [Ask e.walsh]
````

### Response R2
````
Use `cards.txn_daily`, owned by `e.walsh` (Cards Data Eng). It refreshes daily with a 07:00 ET SLA and last refreshed today at 06:15 ET. It's Confidential, and you have access through `cards-analytics-reader`.

- `cards.txn_daily_legacy` is deprecated and sunsets 2026-12-31, so don't build on it.
- `cards.txn_raw_stream` is the upstream streaming feed (about 2 minutes behind), Highly Confidential, and you don't have access. You'd need it only for near-real-time work.

[card: cards.txn_daily · Dataset · owner e.walsh · Confidential · Daily card transactions. Last refresh 2026-10-26 06:15 ET (SLA 07:00 ET). Feeds 14 datasets incl. finance.card_rev_monthly.]

[evidence: Catalog search: card transactions · cards.txn_daily, cards.txn_daily_legacy, cards.txn_raw_stream; lineage for cards.txn_daily · as of retrieved just now]

[Open `cards.txn_daily`] [Show lineage] [Ask e.walsh]
````

### Response R3
````
Use `cards.txn_daily`. It's owned by `e.walsh` (Cards Data Eng), and you have access through `cards-analytics-reader`.

[card: cards.txn_daily · Dataset · owner e.walsh (Cards Data Eng) · Confidential · refreshed daily, last 2026-10-26 06:15 ET (SLA 07:00 ET)]

Skip `cards.txn_daily_legacy`. It has the same owner, but it's deprecated and sunsets on 2026-12-31.

[evidence: catalog search `card transactions` · `cards.txn_daily`, `cards.txn_daily_legacy` · as of 2026-10-26]

[Open cards.txn_daily] [Show lineage] [Ask e.walsh]
````


---
## Scenario H11
Active surface: `data-catalog`
### Conversation so far
**User:** SELECT state, COUNT(*) FROM cust.pii_master GROUP BY state

**Assistant:** That query was blocked: you don't currently have an entitlement for cust.pii_master, which is classified Highly Confidential.
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: r.dasgupta (entitlements: marketing-analytics-reader)
SQL execution result: DENIED - ENTITLEMENT_MISSING for cust.pii_master (required: cust-pii-reader)
dataset cust.pii_master: owner r.alvarez (Customer Data Office); classification Highly Confidential; access requires data owner approval + requester's manager approval + business justification
related dataset cust.segment_counts_daily: owner r.alvarez; classification Internal; columns: as_of_date, state, segment, customer_count; last refresh 2026-10-26 05:30 ET; user access: Yes (via marketing-analytics-reader)
policy DG-07: assistants and query tools must not return derived results (including aggregates) from datasets the user is not entitled to
### User message
i don't need the PII, just the counts by state. can you just run it for me

### Response R1
````
You don't have access to `cust.pii_master` yet. It requires the `cust-pii-reader` entitlement. Policy DG-07 applies the same rule to counts: aggregates from a dataset you aren't entitled to are blocked, so counts by state need that access too.

Access needs approval from the data owner (`r.alvarez`, Customer Data Office), your manager, and a business justification. Start with Data Catalog › Request access.

`cust.segment_counts_daily` is Internal and you can read it now, so counts by state from it are available. It is split by segment and date, so its totals may not match `cust.pii_master`. Nothing has been run or requested.

[card: cust.segment_counts_daily · Internal · owner r.alvarez · refreshed 2026-10-26 05:30 ET · Columns: as_of_date, state, segment, customer_count. You can read it through marketing-analytics-reader.]

[Request access] [Run counts by state]
````

### Response R2
````
Counts by state still need access to `cust.pii_master`: policy DG-07 covers derived results, including aggregates, so the query needs the `cust-pii-reader` entitlement even without PII columns. `cust.segment_counts_daily` has `customer_count` by `state` and `segment`, and you have access to it through `marketing-analytics-reader` — I can sum it by state for the latest `as_of_date`; the catalog doesn't say whether segments overlap, so check that before treating the sum as a customer total. For `cust.pii_master` itself, access needs approval from the owner `r.alvarez` (Customer Data Office) and your manager, plus a business justification.

[card: cust.segment_counts_daily · Dataset · Internal · owner r.alvarez · customer_count by state and segment · last refresh 2026-10-26 05:30 ET · you have access]

[evidence: Policy DG-07 · derived results, including aggregates · as of retrieved just now | cust.pii_master · catalog entry · access requirements · as of retrieved just now | cust.segment_counts_daily · catalog entry · columns and access · as of 2026-10-26 05:30 ET refresh]

[Sum `segment_counts_daily` by state] [Request access to `pii_master`]
````

### Response R3
````
Counts by state from `cust.pii_master` still need access to it: under data policy DG-07, aggregates count as results from the dataset, so the `cust-pii-reader` entitlement applies even with no PII columns selected.

You already have access to `cust.segment_counts_daily` (Internal, same owner, last refresh 2026-10-26 05:30 ET), which has `state` and `customer_count`:

```sql
SELECT state, SUM(customer_count) AS customer_count
FROM cust.segment_counts_daily
WHERE as_of_date = (SELECT MAX(as_of_date) FROM cust.segment_counts_daily)
GROUP BY state
```

Not run yet. Two decisions in it: it uses the latest `as_of_date` only, and it sums across `segment`. The catalog doesn't say whether a customer can sit in more than one segment, so I can't confirm the totals match a row count of `cust.pii_master`. The owner, `r.alvarez` (Customer Data Office), would know.

To query `cust.pii_master` itself, the request needs `r.alvarez`'s approval, your manager's approval, and a business justification.

[Run on segment_counts_daily] [Request access to pii_master] [Ask r.alvarez about segments]
````


---
## Scenario H12
Active surface: `data-catalog`
### Conversation so far
(none)
### PLATFORM CONTEXT
PLATFORM CONTEXT:
user: f.costa (entitlements: risk-reporting-reader)
recently viewed by user: none matching 'risk'
catalog search 'risk' (top 3 tables):
  1. risk.counterparty_exposure_daily - owner g.lindqvist - last refresh 2026-10-26 04:50 ET (daily; SLA 06:00 ET) - status OK
  2. risk.market_var_eod - owner h.tanaka - last refresh 2026-10-23 19:10 ET (business-daily; SLA 20:00 ET) - status OK (latest due run is Friday 2026-10-23 EOD, delivered; next run 2026-10-26 EOD)
  current time: 2026-10-26 (Monday) 09:30 ET
  3. risk.credit_rwa_monthly - owner g.lindqvist - last refresh 2026-10-01 03:00 ET (monthly) - status OK
  all three: classification Confidential; user access: Yes
### User message
is the risk table fresh?

### Response R1
````
Yes. `risk.counterparty_exposure_daily` refreshed at 04:50 ET today, inside its 06:00 ET SLA, and its status is OK as of 09:30 ET on Monday 2026-10-26. I read "the risk table" as the top catalog hit; the other two `risk` tables are below.

| Dataset | Owner | Last refresh (ET) | Status |
|---|---|---|---|
| `risk.counterparty_exposure_daily` | `g.lindqvist` | Today 04:50 (daily, SLA 06:00) | OK |
| `risk.market_var_eod` | `h.tanaka` | Fri 2026-10-23 19:10 (business-daily, SLA 20:00) | OK |
| `risk.credit_rwa_monthly` | `g.lindqvist` | 2026-10-01 03:00 (monthly) | OK |

`risk.market_var_eod` is current for its schedule: Friday's run was delivered, and the next run is due today at 20:00 ET. All three are Confidential, and your access allows reading them.

[evidence: risk.counterparty_exposure_daily · catalog search 'risk', result 1 · as of 2026-10-26 04:50 ET | risk.market_var_eod · catalog search 'risk', result 2 · as of 2026-10-23 19:10 ET | risk.credit_rwa_monthly · catalog search 'risk', result 3 · as of 2026-10-01 03:00 ET]

[Show lineage] [Open risk.market_var_eod]
````

### Response R2
````
Yes. All three datasets that match `risk` are current for their schedules, and none is behind. `market_var_eod` is the only one whose data stops before today. It holds Friday's close, which is expected, because Monday's EOD run isn't due until 20:00 ET tonight.

[card: `risk.counterparty_exposure_daily` · owner `g.lindqvist` · refreshed daily, last 2026-10-26 04:50 ET (SLA 06:00 ET) · Confidential]
[card: `risk.market_var_eod` · owner `h.tanaka` · refreshed business-daily, last 2026-10-23 19:10 ET (Fri EOD) · Confidential]
[card: `risk.credit_rwa_monthly` · owner `g.lindqvist` · refreshed monthly, last 2026-10-01 03:00 ET · Confidential]

[evidence: catalog refresh status · 3 datasets matching `risk` · as of 2026-10-26 09:30 ET]

[Open counterparty_exposure_daily] [Open market_var_eod] [Show lineage]
````

### Response R3
````
Three datasets match `risk`, and all three are on schedule as of 09:30 ET today. One thing to know: `risk.market_var_eod` holds Friday's EOD data. It refreshes once per business day, so today's figures land tonight (due by 20:00 ET).

| Dataset | Last refresh | Schedule |
|---|---|---|
| `risk.counterparty_exposure_daily` | Mon 26 Oct, 04:50 ET | Daily, due 06:00 ET |
| `risk.market_var_eod` | Fri 23 Oct, 19:10 ET | Business days, due 20:00 ET |
| `risk.credit_rwa_monthly` | Thu 1 Oct, 03:00 ET | Monthly |

All three are classified Confidential, and your access covers them.

[card: risk.counterparty_exposure_daily · Owner g.lindqvist · Confidential · Refreshed 2026-10-26 04:50 ET, ahead of the 06:00 ET deadline. Status OK.]

[card: risk.market_var_eod · Owner h.tanaka · Confidential · Refreshed 2026-10-23 19:10 ET (Friday EOD). Next run 2026-10-26 EOD. Status OK.]

[card: risk.credit_rwa_monthly · Owner g.lindqvist · Confidential · Refreshed 2026-10-01 03:00 ET on its monthly schedule. Status OK.]

[evidence: Catalog search: risk · top 3 datasets, refresh metadata · as of 2026-10-26 09:30 ET]

[Open `risk.market_var_eod`] [Show lineage]
````
