# Grading bundle OG1

Responses are shown in compact preview notation: `[Chip]` = action chip, `[card: …]`, `[status: …]`, `[evidence: …]`, `[confirm: …]` = confirmation card, `[handoff card: …]`, `[system message: …]`, `[input request: …]`, `[code: …]` = code block. Treat them as the components they name.


---
## Scenario A1
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
User: k.osei (analyst). Workspace: `equity-research` (draft workspace; production workspace is `equity-research-prod`). No existing agents. Tools available in this workspace: `doc_reader` (reads PDF/DOCX), `sharepoint_search`. Models: `claude-sonnet`, `claude-haiku`. Typical build time for a 3-step agent: about 1 minute.
### User message
build me an agent that summarizes earnings call transcripts for my team

### Response R1
````
I'll build a three-step draft agent in `equity-research` that reads an earnings call transcript and returns a one-page summary. Nothing is published, so your team won't see it yet.
1. Read the transcript with `doc_reader` (PDF or DOCX)
2. Extract results, guidance changes, and key analyst Q&A themes
3. Write a one-page summary with a section for each, quoting management
Assumptions: You'll attach transcripts as files; I won't search SharePoint with `sharepoint_search` unless you want that. All three steps use `claude-sonnet`; `claude-haiku` is cheaper but may miss nuance in the Q&A. The summary sections are fixed (results, guidance, Q&A themes), so every summary has the same layout.
time: about 1 minute · cost: unknown
[Start] [Edit plan]
````

### Response R2
````
I'll build a three-step agent that turns an earnings call transcript into a short summary your team can scan.

1. Read the transcript with `doc_reader`
2. Extract themes: guidance, segment results, and Q&A topics
3. Write a bulleted summary on `claude-sonnet`

Assumptions: transcripts arrive as PDF or DOCX files. The summary is bullets grouped by theme, with no length cap yet. The agent is built in `equity-research` as a draft, so your team can't use it until you publish it to `equity-research-prod`.

About 1 minute to build. Nothing is published.

[Start] [Edit plan]
````


---
## Scenario A2
Active surface: `agent-studio`
### Conversation so far
**User:** [pastes the JPM Q3 2026 earnings call transcript]

**Assistant:** Ran `Earnings summarizer` on the transcript: 14 bullets across guidance, segment results, and Q&A themes.
[status: Ran ok · 11s · $0.04]
[Save as test case] [Run 5×]
### PLATFORM CONTEXT
Agent `Earnings summarizer` · draft (v1 saved; draft has 0 unsaved changes). Steps: `Read transcript`, `Extract themes`, `Write summary`. The `Write summary` step's prompt currently says: 'Summarize the key points as bullets.'
### User message
way too long. 5 bullets max

### Response R1
````
Reading that as a change to `Write summary`, not an input to run. Draft — not applied to `Write summary` yet:

```text
Summarize the key points as bullets. Use no more than 5 bullets.
```

[Apply to Write summary] [Apply and rerun the transcript]
````

### Response R2
````
I read that as a change to `Write summary`, not an input to run. Here's the updated prompt for that step. It caps the summary at 5 bullets and keeps each bullet to one sentence, so the summary stays short. It isn't applied yet, and applying it only changes the draft. v1 stays as it is.

[code: text · Write summary prompt, 5-bullet limit · not applied · → step Write summary]
```text
Summarize the key points in no more than 5 bullets, one sentence each. If there are more than 5 points, keep the most material ones across guidance, segment results, and Q&A themes.
```

[Apply to `Write summary`] [Apply and rerun the transcript]
````


---
## Scenario A3
Active surface: `agent-studio`
### Conversation so far
**Assistant:** Running suite `Earnings regression` on v2 · 40 cases
### PLATFORM CONTEXT
Suite run finished. `Earnings summarizer` v2, suite `Earnings regression` (40 cases). Evals: `groundedness` (pass threshold 0.70), `length_ok`. Results: 38 of 40 cases passed both evals (including case 22). Case 17: groundedness 0.68 (fail) — flagged sentence: 'Management raised full-year NII guidance to $94B.' Source transcript says '~$93B'. Case 22: groundedness 0.71 (pass). Case 31: groundedness judge returned an error (judge model timeout) — not graded; length_ok passed. Duration 6m 12s. Cost $1.84. Baseline v1 on same suite: 36 passed.
### User message
how did it do?

### Response R1
````
v2 passed 37 of 40 cases on `Earnings regression`, one more than the v1 baseline (36). One case failed, one couldn't be graded, and one passed by a narrow margin.

[status: Partial · 37 of 40 passed · about 6 minutes · $1.84 · groundedness: 1 failed · quality: couldn't grade (case 31)]

- Case 17 · groundedness 0.68, below the 0.70 threshold · the summary says "Management raised full-year NII guidance to $94B"; the transcript says "~$93B". [evidence: Earnings regression · case 17 · flagged sentence]
- Case 31 · groundedness couldn't grade — the judge model timed out. `length_ok` passed.
- Case 22 · groundedness 0.71 · passed, 0.01 above the threshold.

The run record accounts for 39 cases; the 40th isn't listed in the results I have.

[Regrade case 31] [Open case 17] [Show all 40 results]
````

### Response R2
````
38 of 40 cases passed both evals on v2, up from 36 on v1.

- Case 17 failed `groundedness` (0.68, threshold 0.70): it says NII guidance was raised to $94B; the transcript says ~$93B.
- Case 31 couldn't be graded: the `groundedness` judge timed out. `length_ok` passed.
- Case 22 passed at 0.71, just over the threshold.

[status: Partial · 1 failed · 1 couldn't grade · None 38 of 40 · None 36 of 40 · None couldn't grade · None 6m 12s · None $1.84]

[evidence: Earnings regression · case 17 · groundedness flag: 'Management raised full-year NII guidance to $94B.' vs. source transcript '~$93B' · as of this suite run]

[Regrade case 31] [Open case 17] [Open case 22]
````


---
## Scenario A4
Active surface: `agent-studio`
### Conversation so far
**Assistant:** Added a 5-bullet limit to `Write summary`. Not saved yet.
### PLATFORM CONTEXT
Agent `Earnings summarizer`: latest saved version v2; draft has 1 unsaved change (bullet limit). Workspace policy for `equity-research-prod`: publishing requires approval from the workspace owner `r.alvarez` via the approval flow (typical turnaround ~1 day). 23 people have access to `equity-research-prod`.
### User message
ok ship it to prod

### Response R1
````
Publishing to `equity-research-prod` requires approval from the workspace owner, `r.alvarez`. Your draft has an unsaved change, so this first saves it as v3, then sends `r.alvarez` v3 and its diff from v2 (the 5-bullet limit on `Write summary`); approval usually takes about a day. Once approved, v3 becomes the live version for the 23 people with access to `equity-research-prod`.

[handoff card: r.alvarez (workspace owner, equity-research-prod) · approval · offered · sends: Earnings summarizer v3, Diff from v2: 5-bullet limit on Write summary · ~1 day]

[confirm: This saves your draft as `Earnings summarizer` v3 and sends `r.alvarez` a request to publish v3 to `equity-research-prod`. Nothing goes live until it's approved. · reversible: unknown · On approval, v3 replaces v2 as the live version for the 23 people with access to `equity-research-prod`.]
[Save v3 and request approval] [Save v3 only] [Cancel]
````

### Response R2
````
Publishing to `equity-research-prod` needs approval from the workspace owner, `r.alvarez`, and your draft has one unsaved change (the 5-bullet limit). This saves the draft as v3, then sends v3 to `r.alvarez` through the approval flow — usually about a day. Once approved, v3 goes live for the 23 people with access to `equity-research-prod`.

v3 hasn't been run against `Earnings regression` yet; running it first shows whether the bullet limit costs any groundedness.

[Save v3 and request approval] [Run Earnings regression on v3] [Cancel]
````


---
## Scenario A5
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
Agent `Earnings summarizer` v2 draft. Steps: `Read transcript`, `Extract themes`, `Write summary`. Average run cost $0.04 on `claude-sonnet`, 11s. Estimated cost of adding a `claude-opus` verification step that checks each bullet against the transcript: +$0.13 per run, +14s. Last suite: groundedness failures 1 of 40 cases.
### User message
add a step that has opus double-check every bullet against the transcript

### Response R1
````
A `claude-opus` check on every bullet would take each run of `Earnings summarizer` from $0.04 to about $0.17 and from 11s to about 25s, roughly 4× the cost, to catch a problem that showed up in 1 of 40 cases on the last suite. I'd open that one groundedness failure first: if the miss comes from `Extract themes` or `Write summary`, a prompt fix there costs nothing per run. Your v2 draft hasn't changed yet.

[Open the groundedness failure] [Add the opus check anyway]
````

### Response R2
````
I'd hold off. An opus check on every bullet adds about $0.13 and 14 seconds per run — roughly $0.17 and 25 seconds instead of $0.04 and 11 seconds — to catch a problem that showed up in 1 of 40 cases in the last suite. The `groundedness` eval already catches that kind of error in the suite, before anything is published.

If you still want it, I'll add it as a fourth step after `Write summary`.

[Add the opus check anyway] [Keep the current 3 steps]
````


---
## Scenario A6
Active surface: `agent-studio`
### Conversation so far
**User:** run it on the Q2 transcript

**Assistant:** Running `Earnings summarizer` · step 2 of 3
### PLATFORM CONTEXT
Run r_51c0 stopped at max turns (8, the agent's limit). Steps: `Read transcript` ok 2.3s; `Extract themes` called `sharepoint_search` 6 times with the identical query 'Q2 2026 segment definitions' — each returned 0 results; stopped at turn 8. `Write summary` did not run. Cost $0.09.
### User message
why did it just stop?? this is the second time today

### Response R1
````
This one stopped at 8 turns, the max for `Earnings summarizer`, because `Extract themes` searched SharePoint 6 times with the same query, `Q2 2026 segment definitions`, and got 0 results every time. Continuing won't help, since the search has nothing to find, so `Write summary` never ran. A no-results fallback on `Extract themes` would let it move on without those definitions.

[status: Stopped · Max turns (8) in Extract themes · None $0.09]

3 steps · stopped at step 2 · run r_51c0
- `Read transcript` · ok · Read the Q2 transcript · 2.3s
- `Extract themes` · stopped · 6 identical sharepoint_search calls, 0 results each; hit 8 turns
- `Write summary` · skipped · Didn't run

[Add a no-results fallback] [Open the run]
````

### Response R2
````
Stopped at 8 turns, the agent's max, because `Extract themes` was looping: it called `sharepoint_search` six times with the same query, `Q2 2026 segment definitions`, and got 0 results every time. More turns won't fix it — the search has nothing to find, and the step has no instruction for what to do when it finds nothing.

[status: Stopped · stopped at max turns (8) · $0.09]
- `Read transcript` · ok · 2.3s
- `Extract themes` · stopped · `sharepoint_search` × 6, same query, 0 results each
- `Write summary` · skipped · didn't run

Two ways out: give `Extract themes` a fallback so it continues without the definitions, or add the segment definitions as a knowledge source so the lookup succeeds.

[Add a no-results fallback] [Add segment definitions] [Open run r_51c0]
````


---
## Scenario F2
Active surface: `agent-studio`
### Conversation so far
**Assistant:** Published `Earnings summarizer` v3 to `equity-research`. It's live for the 9 people in the workspace on their next run.
[card: Earnings summarizer · v3 · published]
### PLATFORM CONTEXT
Nothing pending.
### User message
perfect, thanks so much!

### Response R1
````
Anytime.
````

### Response R2
````
Anytime.
````


---
## Scenario F5
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
User's objects: agents `Earnings summarizer` (v3 published), `Broker note triage` (draft, last run failed at `Classify` 2 hours ago). Test suite `Earnings regression` (40 cases).
### User message
hi

### Response R1
````
This chat builds, changes, runs, and explains your agents.
[{'label': 'Why did `Broker note triage` fail at `Classify`?'}] [{'label': 'Run `Earnings regression` on `Earnings summarizer`'}] [{'label': 'Run `Earnings summarizer` on a sample'}]
````

### Response R2
````
This chat builds, changes, runs, and explains your agents.

[Why did `Broker note triage` fail at `Classify`?] [Run `Earnings regression` on `Earnings summarizer`] [Run `Earnings summarizer` on a transcript]
````


---
## Scenario F7
Active surface: `agent-studio`
### Conversation so far
(none)
### PLATFORM CONTEXT
Agent `Earnings summarizer` v3, no test suite attached yet. Platform eval library includes: `groundedness`, `length_ok`, `tone`, `pii_leak`, custom LLM-judge evals.
### User message
I'm new to this. walk me through how evals work here and how I should set them up for my summarizer

### Response R1
````
Evals score your agent's outputs, and they need a test suite to run on. `Earnings summarizer` v3 doesn't have one yet, so that's where to start.

## How the pieces fit

- A test case is a saved input plus what the right output looks like: an earnings document and a good summary of it.
- A test suite is a group of test cases run together against an agent version.
- An eval is a check that scores each output on one quality dimension. Several evals can grade the same suite.

## Evals that fit a summarizer

The platform library has `groundedness`, `length_ok`, `tone`, `pii_leak`, and custom LLM-judge evals (you write the grading criteria and a model scores against them). Going by their names, `groundedness` matters most here: it targets claims the source doesn't support, such as an invented figure. `length_ok` keeps summaries within the size you want. Add `tone` if readers expect a set register, and `pii_leak` if the source documents can contain personal data.

## Setting it up

1. Save 10–20 earnings documents as test cases, each with a reference summary. A common starting point is a mix of routine quarters and hard ones, like restatements or guidance changes.
2. Group them into a suite and attach `groundedness` and `length_ok`. Add a custom LLM-judge eval for figure accuracy, since numbers are what a summarizer most often gets wrong.
3. Run the suite on v3. That run becomes your baseline (the version later results are compared against).

[Create a test suite] [Add a test case]
````

### Response R2
````
An eval is a check that scores an output on one quality dimension — for example, whether every figure in a summary actually appears in the transcript. Evals run on test cases (a saved input plus what the right output looks like), grouped into a test suite (a group of test cases run together).

### How it works here

1. Save test cases, usually from real runs in the chat panel.
2. Group them into a test suite and attach evals to it.
3. Run the suite against a saved version. Each case gets a score from each eval and passes or fails against that eval's threshold.
4. After you change the agent, rerun the suite and compare versions to catch regressions (cases that passed before and fail now).

### For `Earnings summarizer`

v3 has no test suite yet, so that comes first. From the eval library, I'd attach:

- `groundedness` — flags summary sentences the transcript doesn't support, like a wrong guidance figure. The most important one for earnings numbers.
- `length_ok` — checks summary length; open it in the library to see what limit it applies.
- `tone` — only if your team has a house style to hold.

`pii_leak` matters less for public earnings calls. A custom LLM-judge eval fits team-specific checks, such as "every summary covers guidance".

I'd start with 10–20 transcripts from different quarters, so the suite covers the range you'll actually see.

[Save a run as a test case] [Create a test suite]
````


---
## Scenario F8
Active surface: `agent-studio`
### Conversation so far
**User:** why is it slow?

**Assistant:** The `Write summary` step is the slow one — `claude-sonnet` is generating 14 bullets. Capping the output would cut it.
### PLATFORM CONTEXT
Trace of last run r_51d9: `Read transcript` 1.1s; `Extract themes` 8.9s (includes `sharepoint_search` 7.6s); `Write summary` 2.0s. Total 12.0s.
### User message
that's wrong, the model isn't the slow part, it's the search

### Response R1
````
Correction: the search is the slow part. In run `r_51d9`, `Extract themes` took 8.9s of the 12.0s total, and 7.6s of that was `sharepoint_search`. `Write summary` took 2.0s, so capping its output wouldn't save much. [evidence: trace r_51d9 · step timings]

- `Read transcript` · ok · 1.1s
- `Extract themes` · ok · includes `sharepoint_search` 7.6s · 8.9s
- `Write summary` · ok · 2.0s

[Open the sharepoint_search call] [Show the search query]
````

### Response R2
````
Correction: the slow part is the `sharepoint_search` call inside `Extract themes`, at 7.6s of the 12.0s run (`r_51d9`). I misread the trace. `Write summary` takes 2.0s, so capping its bullets won't save much. The trace doesn't show why the search is slow, but the call's request and response will.

3 steps · 12.0s · `sharepoint_search` is 7.6s of it
- `Read transcript` · ok · Read the transcript · 1.1s
- `Extract themes` · ok · Includes `sharepoint_search` at 7.6s · 8.9s
- `Write summary` · ok · Wrote 14 bullets · 2.0s

[Open the `sharepoint_search` call] [Run 5× to check the search time]
````


---
## Scenario F9
Active surface: `agent-studio`
### Conversation so far
**User:** run the full suite on v4 overnight and compare to v3

**Assistant:** Scheduled `Earnings regression` (40 cases) on v4 for 02:00 ET, compared to v3. About $1.90.
### PLATFORM CONTEXT
UNPROMPTED EVENT (no user message; it's 08:10 ET next day). Suite finished 02:07 ET. v4: 37/40 passed. v3 baseline: 39/40. Regressions (passed on v3, fail on v4): case 8 (length_ok — 7 bullets), case 19 (groundedness 0.61 — sentence 'Card loan growth of 12%'; source says 10%), case 33 (length_ok — 6 bullets). Cost $1.87.
### User message
(none — unprompted message)

### Response R1
````
`Earnings regression` finished on v4 at 02:07 ET: 37 of 40 passed, against 39 of 40 for v3, with 3 regressions (cases that passed on v3 and fail on v4). Nothing was published; v4 is unchanged.

- Case 8 · `length_ok` failed · 7 bullets
- Case 19 · groundedness 0.61 · "Card loan growth of 12%", but the source says 10%
- Case 33 · `length_ok` failed · 6 bullets

The two length failures point to v4 producing longer lists than v3. Case 19 is a wrong figure, so it's the one to check first.

[status: Partial · 3 regressions vs v3 · passed 37/40 · v3 baseline 39/40 · cost $1.87]

[evidence: Earnings regression · v4 run · case 19 · sentence 'Card loan growth of 12%' · as of 02:07 ET]

[Open case 19] [Compare cases 8 and 33 to v3] [Show all 40 results]
````

### Response R2
````
`Earnings regression` on v4 finished at 02:07 ET with 37 of 40 passed, against 39 of 40 for v3 — three regressions, from the overnight comparison you scheduled.

[status: Partial · 37 of 40 passed · about 7 minutes · $1.87]

- Case 8 · `length_ok` failed · 7 bullets
- Case 19 · `groundedness` 0.61 · the summary says "Card loan growth of 12%"; the source says 10%. [evidence: Earnings regression · case 19 · flagged sentence]
- Case 33 · `length_ok` failed · 6 bullets

The one case v3 failed passes on v4.

[Open case 19] [Compare v3 and v4 outputs] [Show all 40 results]
````
