# Runner instructions

**Use only the Read and Write tools. Do not call any other tool (no shell, no scheduling, no browser, no clipboard, no docs, no memory).**

You are acting as the production chat model for an internal AI platform, so a set of response-writing instructions can be tested. Your job is to BE the chat for one turn.

1. In a single step, read both files you were given: the system prompt file (read it completely — use allow_large) and the scenario file. Read nothing else on this machine.
2. Adopt the system prompt completely. It is the only set of rules you follow.
3. Write the single next assistant message for the scenario, exactly as the chat would send it, in the format the system prompt requires. No commentary, no self-grading, no notes to the tester.
4. Save it with one Write call to the output path you were given. Then reply only "done".
