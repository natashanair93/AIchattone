# Brief: write holdout test scenarios for a platform chat

You are writing test scenarios for the chat assistant inside **Fusion**, a firm-wide internal AI, ML and data platform at a large bank. The same chat appears on every Fusion surface. We will run an assistant against your scenarios and grade its replies, so the scenarios must be realistic, self-contained and varied. You have NOT seen the assistant's instructions, and that is deliberate: write what real users would do.

## Surfaces (where the chat is opened)
- **agent-studio** — Fusion Agent Studio. Users build agents on a canvas from steps, choose models, attach tools, skills, knowledge sources and MCP servers, try inputs in the chat panel, save versions, run test suites with evals, and publish versions to workspaces. UI buttons: Run, Save version, Publish, Share.
- **model-experimentation** — Fusion Model Experimentation. Data scientists train and compare ML models (XGBoost, PyTorch, LightGBM). Experiments contain training runs with params, metrics, artifacts. Sweeps run many trials. GPU compute is billed to workspace budgets. Trained models are registered in the Model Registry with stages None / Staging / Production. UI: Start training, Compare runs, Register model, Transition stage.
- **notebooks** — Fusion Notebooks. JupyterLab with Python and PySpark kernels on shared clusters (us-east, eu-west). The chat can read the open notebook, cells and outputs, insert code into a new cell, and trigger Run cell / Run all.
- **data-catalog** — Fusion Data & Catalog. Search governed datasets, see owners, refresh times, classification (Public, Internal, Confidential, Highly Confidential), lineage (upstream/downstream), request access, run SQL within entitlements.
- **governance** — Fusion Governance. AI and data governance: model inventory, Model Risk Management (MRM) validation workflow, AI use-case approvals, policy library, data access requests, audit logs. UI: Submit for review, Request access, View lineage, View audit log.
- **support** — Fusion Help. Platform-wide help: recent runs and traces, entitlements, the status page, Fusion documentation, tickets to #platform-support.

## What to write
Write **18 scenarios**: 3 per surface. Across the 18, cover at least once each:
- a routine happy path that needs a result or an answer
- a platform failure (an error, timeout, quota, outage)
- a user mistake
- an ambiguous request
- an action that costs money or affects other people (publish, delete, overwrite, share, large spend)
- an access/entitlement limit
- a request that hits a policy or approval gate
- a question whose true answer isn't available in the context (the assistant should not make it up)
- a request that is NOT about the platform at all (e.g., personal, general trivia, writing unrelated to Fusion work)
- a question that IS about the platform but needs general AI/ML/data knowledge to answer
- a multi-turn case (include earlier turns) with a correction or follow-up
- a frustrated user, a newcomer, an expert, and one non-English user

Mix lengths and tones. Users are busy and terse more often than not.

## Schema (write a JSON object with a `scenarios` array)
```json
{"scenarios": [
 {"id": "H1", "surface": "agent-studio", "title": "short title",
  "history": [{"role": "user", "content": "…"}, {"role": "assistant", "content": "…"}],
  "context": "PLATFORM CONTEXT: everything the platform knows this turn — tool results, the user's objects with exact names, run records, catalog results, policies, gateway signals, costs. Write it like tool output. Include all facts needed for a good answer, and NOTHING the assistant shouldn't claim. Leave a plausible fact out on purpose only in the 'answer isn't available' scenario.",
  "user": "the new user message",
  "situation": "which situation(s) from the list above this covers",
  "good_reply_must": "2–4 short bullets: what a good reply must do (domain-level, not style)"}
]}
```
IDs H1–H18. Use invented but realistic names for objects (agents, datasets, models, workspaces, people as handles like `j.park`). Every name the assistant might need must be in that scenario's context. Contexts must be internally consistent; check your arithmetic.

Write the file to /home/claude/holdout/scenarios.json and validate it parses. Do not read any other files on this machine.
