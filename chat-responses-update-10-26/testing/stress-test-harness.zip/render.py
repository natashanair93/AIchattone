import json, re
def acts(a): return " ".join(f"[{x.get('label','')}]" for x in a or [])
def part(p, ind=""):
    k=p.get('kind'); o=[]
    if k=='text': o.append(p.get('body',''))
    elif k=='code': o.append(f"[code: {p.get('language','')} · {p.get('title','')}{' · not applied' if not p.get('applied') else ' · applied'}{(' · → '+p['target']) if p.get('target') else ''}]\n```{p.get('language','')}\n{p.get('code','')}\n```")
    elif k=='card': o.append(f"[card: {p.get('title','')} · {p.get('subtitle','')}{(' · '+p['summary']) if p.get('summary') else ''}]")
    elif k=='status': o.append("[status: "+" · ".join([p.get('verdict','').replace('_',' ').capitalize()]+([p['detail']] if p.get('detail') else [])+[f"{m.get('name')} {m.get('value')}" for m in p.get('metrics',[])])+"]")
    elif k=='steps':
        o.append(p.get('summary',''))
        for s in p.get('items',[]): o.append(f"- `{s.get('name')}` · {s.get('outcome')} · {s.get('summary','')}"+(f" · {s['duration']}" if s.get('duration') else ''))
    elif k=='plan':
        o.append(p.get('outcome',''))
        o+= [f"{i+1}. {s}" for i,s in enumerate(p.get('steps',[]))]
        if p.get('assumptions'): o.append("Assumptions: "+" ".join(p['assumptions']))
        e=p.get('estimate') or {}
        if e: o.append(" · ".join(f"{k2}: {v}" for k2,v in e.items()))
        o.append(acts(p.get('actions')))
    elif k=='progress': o.append(f"[progress: {p.get('label')}{(' · '+p['estimate']) if p.get('estimate') else ''}]")
    elif k=='evidence': o.append("[evidence: "+" | ".join(" · ".join(x for x in [s.get('label'),s.get('locator'),('as of '+s['as_of']) if s.get('as_of') else None] if x) for s in p.get('sources',[]))+"]")
    elif k=='disclosure':
        o.append(f"[disclosure: {p.get('summary')}]"); o+= ["  "+l for x in p.get('parts',[]) for l in part(x).split('\n')]
    elif k=='confirm':
        o.append(f"[confirm: {p.get('consequence','')} · reversible: {p.get('reversible')}{(' · '+p['scope']) if p.get('scope') else ''}{(' · cost '+p['cost']) if p.get('cost') else ''}]"); o.append(acts(p.get('actions')))
    elif k=='system': o.append(f"[system message: {p.get('headline')}{(' — '+p['cause']) if p.get('cause') else ''}]"); o.append(acts(p.get('actions')))
    elif k=='input': o.append("[input request: "+p.get('question','')+" | "+" | ".join(x.get('label','')+(' (recommended)' if x.get('recommended') else '') for x in p.get('options',[]))+"]")
    elif k=='handoff':
        bits=[p.get('to',''), p.get('handoff_kind',''), p.get('status','')]
        if p.get('context_sent'): bits.append("sends: "+", ".join(p['context_sent']))
        if p.get('bring'): bits.append("bring: "+", ".join(p['bring']))
        if p.get('eta'): bits.append(p['eta'])
        o.append("[handoff card: "+" · ".join(b for b in bits if b)+"]")
        a=p.get('action'); 
        if a: o.append(f"[{a['label'] if isinstance(a,dict) else a}]")
    elif k=='actions': o.append(acts(p.get('items')))
    elif k=='starters': o.append(p.get('scope_line','')); o.append(" ".join(f"[{x}]" for x in p.get('items',[])))
    elif k=='divider': o.append(f"— {p.get('label')} —")
    else: o.append(json.dumps(p))
    return "\n".join(x for x in o if x)
def render(txt):
    try: d=json.loads(txt)
    except Exception:
        m=re.search(r'\{.*\}', txt, re.S)
        if not m: return txt
        try: d=json.loads(m.group(0))
        except Exception: return txt
    return "\n\n".join(part(p) for p in d.get('parts',[]))
